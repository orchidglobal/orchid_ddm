class HTMLOrchidTabElement extends HTMLElement {
  constructor() {
    super();

    this.init();
  }

  init() {}
}

customElements.define('orchid-tab', HTMLOrchidTabElement);
