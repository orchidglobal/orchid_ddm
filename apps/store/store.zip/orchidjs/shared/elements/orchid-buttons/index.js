class HTMLOrchidButtonsElement extends HTMLMenuElement {
  constructor() {
    super();

    this.init();
  }

  init() {}
}

customElements.define('orchid-buttons', HTMLOrchidButtonsElement);
