!(function (exports) {
  'use strict';

  const _ = {};

  exports._ = _;
})(window);
