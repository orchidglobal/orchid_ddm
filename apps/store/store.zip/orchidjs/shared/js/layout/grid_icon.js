class GridIcon {
  constructor (gridElement) {
    this.element = gridElement;

    this.init();
  }

  init () {

  }
}
