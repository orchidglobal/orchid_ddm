class Grid {
  constructor (gridElement) {
    this.element = gridElement;

    this.init();
  }

  init () {

  }
}
