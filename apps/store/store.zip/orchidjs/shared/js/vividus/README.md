# Orchid Vividus Engine

It's a game engine meant to replicate the high definition visuals of a movie with majestic colors and views so it wont be as boring to look at as a movie

It features:
- High DPI GUI with ability to do smooth motion effects to make it more immersive
- Color-tinted bright but realistic art style by default (Can easily be customized)
- Great performance and well-optimized code to ensure your game is able to run on most devices

It's not a complete Unreal Engine replacement but it's already very close. We are trying to make web gaming just as good if not better so web OSes don't lack in the term of gaming

**For official stable releases of OrchidOS. Vividus would usually lay here but for this source code. You currently have to manually get Vividus Manual API set**
