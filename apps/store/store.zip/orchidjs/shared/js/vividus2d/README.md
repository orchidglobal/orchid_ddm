# Orchid Vividus 2D Engine

It's Vividus but for 2D. It's a great game engine for 2D (2.5D) games with 3D-like visuals and shading or complex cartoon-like character animations

You could do things like a seemingly 2D game with 3D-like objects and expressive well-animated characters like how Angry Birds 2 does it

**For official stable releases of OrchidOS. Vividus would usually lay here but for this source code. You currently have to manually get Vividus Manual API set**
